Proyecto Repuestos - AutoRepuestos
Instrucciones: Coloca este directorio en tu htdocs (XAMPP) o en el root de tu servidor PHP. Abrir index.php en el navegador.
