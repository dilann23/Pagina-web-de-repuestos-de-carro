<?php
// footer.php
?>
<footer class="site-footer">
  <div class="container footer-grid">
    <div class="col">
      <a href="index.php" class="logo"><div class="brand-mark">RA</div>AutoRepuestos</a>
      <p class="small">Envíos a todo Colombia • Garantía 12 meses • soporte@autorepuestos.com</p>
    </div>
    <div class="col">
      <h4>Atención</h4>
      <nav class="small">
        <a href="#">Política de envío</a><br>
        <a href="#">Devoluciones</a><br>
        <a href="#">Preguntas frecuentes</a>
      </nav>
    </div>
    <div class="col">
      <h4>Síguenos</h4>
      <p class="small">Instagram · Facebook · WhatsApp</p>
    </div>
  </div>
</footer>
