<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Envío — RepuestosAuto</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <main class="container">
    <div class="form-card">
      <h2 class="center">Dirección de envío</h2>
      <form action="pago.php" method="post">
        <label>Nombre completo</label>
        <input class="input" name="fullname" required>
        <label>Dirección</label>
        <input class="input" name="address" required>
        <div class="form-row">
          <div class="col">
            <label>Ciudad</label>
            <input class="input" name="city" required>
          </div>
          <div class="col">
            <label>Departamento</label>
            <input class="input" name="state" required>
          </div>
        </div>
        <div class="form-row">
          <div class="col">
            <label>Código postal</label>
            <input class="input" name="zip" required>
          </div>
          <div class="col">
            <label>Teléfono</label>
            <input class="input" name="phone" required>
          </div>
        </div>
        <button class="btn" type="submit">Continuar</button>
      </form>
    </div>
  </main>
</body>
</html>
