<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Iniciar sesión — RepuestosAuto</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <main class="container">
    <div class="form-card">
      <h2 class="center">Iniciar sesión</h2>
      <form action="#" method="post">
        <label for="email">Correo electrónico</label>
        <input id="email" class="input" type="email" required>
        <label for="password">Contraseña</label>
        <input id="password" class="input" type="password" required minlength="6">
        <div class="row" style="justify-content:space-between;margin-top:8px">
          <a class="small" href="#">Olvidé mi contraseña</a>
          <button class="btn" type="submit">Entrar</button>
        </div>
      </form>
      <p class="center small" style="margin-top:14px">¿No tienes cuenta? <a href="register.php">Regístrate</a></p>
    </div>
  </main>
</body>
</html>
