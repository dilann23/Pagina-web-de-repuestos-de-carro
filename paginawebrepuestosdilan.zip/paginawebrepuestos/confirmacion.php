<?php include 'header.php'; ?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Pedido confirmado — RepuestosAuto</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <main class="container centered">
    <div class="form-card center">
      <h2>¡Pedido confirmado!</h2>
      <p>Gracias por tu compra. Tu número de pedido es <strong>#100123</strong>.</p>
      <p class="small">Recibirás un correo con los detalles y el seguimiento del envío.</p>
      <a class="btn" href="index.php" style="margin-top:12px;display:inline-block">Volver al inicio</a>
    </div>
  </main>
<?php include 'footer.php'; ?>
</body>
</html>
