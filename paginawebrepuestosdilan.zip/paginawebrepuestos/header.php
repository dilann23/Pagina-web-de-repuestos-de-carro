<?php
// header.php - incluido en páginas públicas
?>
<header class="header">
  <div class="container header-inner">
    <a href="index.php" class="logo"><div class="brand-mark">RA</div>AutoRepuestos</a>

    <form class="searchbar" action="productos.php" method="get" role="search">
      <input type="search" name="q" placeholder="Buscar repuestos, marca o modelo..." aria-label="Buscar" />
      <button type="submit">Buscar</button>
    </form>

    <div class="nav-actions">
      <nav class="main-nav">
        <a href="index.php">Inicio</a>
        <a href="productos.php">Productos</a>
        <a href="#">Guía</a>
        <a href="#">Soporte</a>
      </nav>
      <div class="row">
        <a class="icon-btn" href="login.php">Iniciar</a>
        <a class="icon-btn" href="carrito.php">Carrito</a>
      </div>
    </div>
  </div>
</header>
