<?php include 'header.php'; ?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>RepuestosAuto — Inicio</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
<main class="container">
  <section class="hero">
    <div class="hero-left">
      <h1>Repuestos originales y compatibles — envío nacional</h1>
      <p>Encuentra las piezas que tu vehículo necesita: baterías, frenos, filtros, aceite y mucho más.</p>
      <div class="hero-cta">
        <a class="btn" href="productos.php">Ver catálogo</a>
        <a class="btn" href="#" style="background:transparent;color:var(--accent);border:1px solid var(--glass)">Contactar</a>
      </div>
      <div style="margin-top:18px">
        <div class="section-title"><h2>Categorías</h2><a class="small" href="productos.php">Ver todo</a></div>
        <div class="chips">
          <a href="productos.php?cat=baterias">Baterías</a>
          <a href="productos.php?cat=frenos">Frenos</a>
          <a href="productos.php?cat=filtrado">Filtrado</a>
          <a href="productos.php?cat=iluminacion">Iluminación</a>
          <a href="productos.php?cat=aceites">Aceites</a>
        </div>
      </div>
    </div>
    <aside class="hero-card">
      <img src="assets/hero-placeholder.png" alt="Imagen principal">
      <p class="mb small">Ofertas del día: baterías con 15% de descuento y envíos gratis en compras mayores a $350.000</p>
      <a class="btn" href="productos.php">Ver ofertas</a>
    </aside>
  </section>
  <section class="mb">
    <div class="section-title">
      <h2>Productos destacados</h2>
      <a class="small" href="productos.php">Ver todo</a>
    </div>
    <div class="feature-grid">
      <article class="prod-card">
        <img src="assets/bateria.png" alt="Batería 12V">
        <div class="prod-meta">
          <div>
            <div class="prod-title">Batería 12V — Modelo X</div>
            <div class="small sku">SKU: BAT-12X</div>
          </div>
          <div class="prod-price">$350.000</div>
        </div>
      </article>
      <article class="prod-card">
        <img src="assets/filtro.png" alt="Filtro de aire">
        <div class="prod-meta">
          <div>
            <div class="prod-title">Filtro de aire — Marca Y</div>
            <div class="small sku">SKU: FIL-88</div>
          </div>
          <div class="prod-price">$45.000</div>
        </div>
      </article>
      <article class="prod-card">
        <img src="assets/pastillas.png" alt="Pastillas de freno">
        <div class="prod-meta">
          <div>
            <div class="prod-title">Pastillas de freno delanteras</div>
            <div class="small sku">SKU: PF-44</div>
          </div>
          <div class="prod-price">$120.000</div>
        </div>
      </article>
    </div>
  </section>
</main>
<?php include 'footer.php'; ?>
</body>
</html>
