<?php include 'header.php'; ?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Catálogo — RepuestosAuto</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
<main class="container">
  <div class="layout">
    <aside class="filters">
      <h3>Filtrar</h3>
      <div class="mb">
        <label>Categoria</label>
        <select class="input">
          <option>Todos</option>
          <option>Baterías</option>
          <option>Frenos</option>
        </select>
      </div>
      <div class="mb">
        <label>Marca</label>
        <input class="input" placeholder="Marca">
      </div>
      <div class="mb">
        <label>Precio (mín - máx)</label>
        <div class="form-row"><input class="input" placeholder="Min"><input class="input" placeholder="Max"></div>
      </div>
      <button class="btn">Aplicar filtros</button>
    </aside>
    <section>
      <div class="section-title"><h2>Resultados</h2><div class="small">12 resultados</div></div>
      <div class="products-list">
        <article class="prod-card">
          <img src="assets/correa.png" alt="Correa">
          <div class="prod-meta">
            <div><div class="prod-title">Correa de distribución</div><div class="small sku">SKU: CD-1234</div></div>
            <div class="prod-price">$220.000</div>
          </div>
          <div style="margin-top:10px"><a class="btn" href="detalle.php">Ver</a></div>
        </article>
        <article class="prod-card">
          <img src="assets/amortiguador.png" alt="Amortiguador">
          <div class="prod-meta">
            <div><div class="prod-title">Amortiguador trasero</div><div class="small sku">SKU: AM-998</div></div>
            <div class="prod-price">$450.000</div>
          </div>
          <div style="margin-top:10px"><a class="btn" href="detalle.php">Ver</a></div>
        </article>
      </div>
    </section>
  </div>
</main>
<?php include 'footer.php'; ?>
</body>
</html>
