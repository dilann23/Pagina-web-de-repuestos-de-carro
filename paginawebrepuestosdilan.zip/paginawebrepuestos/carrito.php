<?php include 'header.php'; ?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Carrito — RepuestosAuto</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
<main class="container">
  <h2>Tu carrito</h2>
  <div style="display:grid;grid-template-columns:1fr 360px;gap:20px;margin-top:14px">
    <div>
      <table class="table">
        <thead><tr><th>Producto</th><th>Cantidad</th><th>Precio</th><th></th></tr></thead>
        <tbody>
          <tr>
            <td>Correa de distribución<br><span class="small sku">SKU: CD-1234</span></td>
            <td><input class="input" type="number" value="1" min="1" style="width:90px"></td>
            <td>$220.000</td>
            <td><button class="icon-btn">Eliminar</button></td>
          </tr>
        </tbody>
      </table>
    </div>
    <aside class="checkout-card">
      <h3>Resumen</h3>
      <p class="small">Subtotal: $220.000</p>
      <p class="small">Envío: $15.000</p>
      <p style="font-weight:800;margin-top:6px">Total: $235.000</p>
      <a class="btn" href="envio.php" style="display:block;margin-top:12px">Proceder al pago</a>
    </aside>
  </div>
</main>
<?php include 'footer.php'; ?>
</body>
</html>
