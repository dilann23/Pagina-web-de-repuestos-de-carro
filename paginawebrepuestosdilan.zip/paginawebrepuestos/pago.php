<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Método de pago — RepuestosAuto</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <main class="container">
    <div class="form-card">
      <h2 class="center">Método de pago</h2>
      <form action="confirmacion.php" method="post">
        <label class="small"><input type="radio" name="method" value="card" checked> Tarjeta de crédito / débito</label>
        <label class="small">Número de tarjeta</label>
        <input class="input" inputmode="numeric" maxlength="19" placeholder="1234 1234 1234 1234">
        <div class="form-row">
          <div class="col">
            <label class="small">MM/AA</label>
            <input class="input" maxlength="5" placeholder="MM/AA">
          </div>
          <div class="col">
            <label class="small">CVC</label>
            <input class="input" maxlength="4" placeholder="CVC">
          </div>
        </div>
        <label class="small"><input type="radio" name="method" value="cod"> Contra entrega</label>
        <button class="btn" type="submit">Pagar</button>
      </form>
    </div>
  </main>
</body>
</html>
