<?php include 'header.php'; ?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Detalle — Correa de distribución</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
<main class="container">
  <div class="product-detail">
    <div class="gallery"><img src="assets/correa_large.png" alt="Correa"></div>
    <aside class="info-box">
      <div class="sku">SKU: CD-1234</div>
      <h2>Correa de distribución</h2>
      <div class="price-large">$220.000</div>
      <p class="small">Correa de alta resistencia compatible con varios modelos. Durabilidad extendida y garantía de 12 meses.</p>
      <form action="carrito.php" method="get" style="margin-top:14px">
        <label class="small">Cantidad</label>
        <input class="input" type="number" value="1" min="1">
        <div style="margin-top:12px;display:flex;gap:10px">
          <button class="btn" type="submit">Añadir al carrito</button>
          <a class="btn" href="#" style="background:transparent;color:var(--accent);border:1px solid rgba(11,110,253,0.08)">Comprar ahora</a>
        </div>
      </form>
      <section style="margin-top:18px">
        <h3>Especificaciones técnicas</h3>
        <ul class="specs">
          <li>Material: Caucho reforzado</li>
          <li>Compatibilidad: Varios modelos</li>
          <li>Garantía: 12 meses</li>
        </ul>
      </section>
    </aside>
  </div>
</main>
<?php include 'footer.php'; ?>
</body>
</html>
