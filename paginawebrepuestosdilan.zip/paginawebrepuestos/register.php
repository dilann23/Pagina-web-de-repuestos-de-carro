<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Registro — RepuestosAuto</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <main class="container">
    <div class="form-card">
      <h2 class="center">Crear cuenta</h2>
      <form action="#" method="post">
        <div class="form-row">
          <div class="col">
            <label>Nombre completo</label>
            <input class="input" type="text" required>
          </div>
        </div>
        <label>Correo electrónico</label>
        <input class="input" type="email" required>
        <div class="form-row">
          <div class="col">
            <label>Contraseña</label>
            <input class="input" type="password" required minlength="6">
          </div>
          <div class="col">
            <label>Confirmar contraseña</label>
            <input class="input" type="password" required minlength="6">
          </div>
        </div>
        <button class="btn" type="submit">Registrarse</button>
      </form>
      <p class="center small" style="margin-top:12px">¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a></p>
    </div>
  </main>
</body>
</html>
